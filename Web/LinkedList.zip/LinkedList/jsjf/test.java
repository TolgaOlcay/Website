package jsjf;

public class test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//used to test linkedorderedlist
		LinkedOrderedList<String> list = new LinkedOrderedList<String>();
		
		list.add("monkey");
		list.add("banana");
		list.add("donkey");
		list.add("zoo");
		list.add("beehive");
		list.add("1");
		list.add("apple");
		
		System.out.println(list);
	}

}
