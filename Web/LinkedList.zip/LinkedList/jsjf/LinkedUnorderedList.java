package jsjf;

import jsjf.exceptions.*;

/**
 * LinkedUnorderedList represents a singly linked implementation of an 
 * unordered list.
 *
 * @author Java Foundations
 * @version 4.0
 */
public class LinkedUnorderedList<T> extends LinkedList<T> 
implements UnorderedListADT<T>
{
	/**
	 * Creates an empty list.
	 */
	public LinkedUnorderedList()
	{
		super();
	}

	/**
	 * Adds the specified element to the front of this list.
	 *
	 * @param element the element to be added to the list
	 */
	public void addToFront(T element)
	{
		// To be completed as a Programming Project
		LinearNode<T> elementNode = new LinearNode(element);
		
		if(isEmpty() == true) {//if there are no elements in the list, add the element to the head
			head = elementNode;
		}else {
		
		elementNode.setNext(head);//set the new element to point to the head node, then make the head the new element node
		head = elementNode;
		
		}
		
		
		
		//find tail
		LinearNode<T> tailNode = head;
		while(tailNode.getNext() != null) {
			tailNode = tailNode.getNext();
			}
		tail = tailNode;
		
		
		count++;
		modCount++;
	}

	/**
	 * Adds the specified element to the rear of this list.
	 *
	 * @param element the element to be added to the list
	 */
	public void addToRear(T element)
	{
		// To be completed as a Programming Project
		
		
		LinearNode<T> elementNode = new LinearNode(element);
		
		if(isEmpty() == true) {
			head = elementNode;
		}else {
		
		tail.setNext(elementNode);
		tail = elementNode;

		
		}
		
		//find tail
		LinearNode<T> tailNode = head;
		while(tailNode.getNext() != null) {
			tailNode = tailNode.getNext();
			}
		tail = tailNode;
		
		
		count++;
		modCount++;
		
	}


	/**
	 * Adds the specified element to this list after the given target.
	 *
	 * @param  element the element to be added to this list
	 * @param  target the target element to be added after
	 * @throws ElementNotFoundException if the target is not found
	 */
	public void addAfter(T element, T target)
	{
		
		
		if(isEmpty())
			throw new EmptyCollectionException("LinkedList");
		// To be completed as a Programming Project
		int size = size();
		LinearNode<T> elementNode = new LinearNode(element);
		LinearNode<T> curr = head;
		int countNode = 1;
		String name = target.toString();//name used for element not found exception 
		
		while(curr != null && curr.getElement() != target) { //loop through the list to find the target
			curr = curr.getNext();
			countNode++;
		}
		
		if(countNode == 1) { //if the target is the head then add the element after the head and make the element point to the node that is after the head
			LinearNode<T> after = curr.getNext();
			elementNode.setNext(after);
			head.setNext(elementNode);
			count++;
			modCount++;
			
		}else if(countNode == size) { //if target is the tail, set the tail next to point to the element
			tail.setNext(elementNode);
			tail = elementNode;
			count++;
			modCount++;
		}else if(curr != null) {//if the target is not the head or not the tail, yet still exisits within the list
			LinearNode<T> after = curr.getNext();
			elementNode.setNext(after);
			curr.setNext(elementNode);
			count++;
			modCount++;
		}else {
			throw new ElementNotFoundException(name);//target is not in the list
		}
		
	}	
}
