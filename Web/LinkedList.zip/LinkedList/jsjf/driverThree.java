package jsjf;

public class driverThree {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkQueue<String> list = new LinkQueue<String>();
		
		list.enqueue("tolga");
		list.enqueue("olcay");
		list.enqueue("zoo");
		list.enqueue("beehive");
		list.enqueue("1");
		list.enqueue("2");
		list.enqueue("monkey");
		System.out.println("first: " + list.first() + "\n");
		
		list.dequeue();
		
		
		System.out.println(list);
		
	}

}
