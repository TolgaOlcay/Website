package jsjf;

import jsjf.exceptions.*;

/**
 * LinkedOrderedList represents a singly linked implementation of an 
 * ordered list.
 *
 * @author Java Foundations
 * @version 4.0
 */
public class LinkedOrderedList<T> extends LinkedList<T> 
implements OrderedListADT<T>
{
	/**
	 * Creates an empty list.
	 */
	public LinkedOrderedList()
	{
		super();
	}

	/**
	 * Adds the specified element to this list at the location determined by
	 * the element's natural ordering. Throws a NonComparableElementException 
	 * if the element is not comparable.
	 *
	 * @param element the element to be added to this list
	 * @throws NonComparableElementException if the element is not comparable
	 */
	public void add(T element)
	{
		// To be completed as a Programming Project
		if (!(element instanceof Comparable))
			throw new NonComparableElementException("OrderedList");

		Comparable<T> comparableElement = (Comparable<T>)element;
		LinearNode<T> elementNode = new LinearNode(element);
		
		
		
		if(isEmpty() == true) {
			head = elementNode;
		}
		
		else {
			LinearNode<T> curr = head;
			LinearNode<T> prev = head;
			
			
			//if there is only one element in the list then we just compare that element and swap posistions in the list as needed
			if(curr.getNext() == null) {
				if(comparableElement.compareTo(curr.getElement()) > 0) {
					
					curr.setNext(elementNode);
					
				}else {
					elementNode.setNext(curr);
					head = elementNode;
				}
			}else {//if there are more than one elment in the list
			
			while(curr.getNext() != null && comparableElement.compareTo(curr.getElement()) > 0) { //travel through the list until we find the correct spot where we can swap
				
					curr = curr.getNext();	
				}
				
			if(comparableElement.compareTo(curr.getElement()) > 0) { //if the new element belongs after the current element, make the new element point to the node that is after curr, and make curr point to the new element
				LinearNode<T> after = curr.getNext();
				curr.setNext(elementNode);
				elementNode.setNext(after); //thus the order is curr -> new element -> node that was previously after curr
			}else {//if the new element belongs before the current node
			
			//find the previous node
			if(prev != curr) { //if the prev and curr arent the same node, loop through the list to find the node that is before curr
				while (prev.getNext() != curr) { 
					prev = prev.getNext();
				}//prev is now the node that is before curr
				
				prev.setNext(elementNode);//sandwich the new element between prev and curr
				elementNode.setNext(curr);//thus the list is prev -> new element -> curr
				
				}else {//if curr and prev are pointing to the same node
				elementNode.setNext(curr);
				head = elementNode;
				
					}	
				}


			}
		}
		
		//find tail
		LinearNode<T> tailNode = head;
		while(tailNode.getNext() != null) {
			tailNode = tailNode.getNext();
		}
		tail = tailNode;
		
		//increase count
		count++;
		modCount++;
	}
}
