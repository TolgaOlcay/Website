package jsjf;

public class ArrayQueue<T> implements QueueADT<T> {
	ArrayUnorderedList<T> queue = new ArrayUnorderedList<T>();
	
	
	@Override
	public void enqueue(T element) {
		// TODO Auto-generated method stub
		queue.addToFront(element);
		
	}

	@Override
	public T dequeue() {
		// TODO Auto-generated method stub
		T last = queue.last();
		queue.removeLast();
		return last;
	}

	@Override
	public T first() {
		// TODO Auto-generated method stub
		T result = queue.first();
		return result;
	}

	@Override
	public boolean isEmpty() {
		// TODO Auto-generated method stub
		boolean empty = queue.isEmpty();
		return empty;
	}

	@Override
	public int size() {
		// TODO Auto-generated method stub
		int size = queue.size();
		
		return size;
	}
	
	public String toString() {
		
		String result = queue.toString();
		return result;
	}
 
}
