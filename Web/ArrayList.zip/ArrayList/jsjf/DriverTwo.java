package jsjf;

public class DriverTwo {
	
	

	public static void main(String[] args) {
		ArrayStack<String> list = new ArrayStack<String>();
	
	
		list.push("tolga");
		list.push("olcay");
		list.push("zoo");
		list.push("beehive");
		list.push("1");
		list.push("2");
		list.push("monkey");
		System.out.println("peek: " + list.peek() + "\n");
	
		list.pop();
	
	
		System.out.println(list);
	}

}
