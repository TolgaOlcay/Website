package jsjf;

public class ArrayStack<T> implements StackADT<T> {
	
	
	ArrayUnorderedList<T> stack = new ArrayUnorderedList<T>();
	

	@Override
	public void push(T element) {
		// TODO Auto-generated method stub
		stack.addToFront(element);
	}

	@Override
	public T pop() {
		// TODO Auto-generated method stub
		T result = stack.first();
		stack.removeFirst();
		return result;
	}

	@Override
	public T peek() {
		// TODO Auto-generated method stub
		T result = stack.first();
		return result;
	}

	@Override
	public boolean isEmpty() {
		// TODO Auto-generated method stub
		boolean result = stack.isEmpty();
		return result;
	}

	@Override
	public int size() {
		// TODO Auto-generated method stub
		int size = stack.size();
		return size;
		
		
	}
	
	public String toString() {
		
		String result = stack.toString();
		return result;
	}


	

}
