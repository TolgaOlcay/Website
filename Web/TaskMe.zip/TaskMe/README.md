# TaskMe
TaskMe is a personal time-management and scheduling calendar application developed by Tolga, Aman, Eathan and Chris for the android platform. At its core, it is a calendar application designed for students. It provides students with a simple and easy to use calendar application that can also be used to track all of their school-related deadlines.
