/*
*	swap_client.c
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>

#define	MAXLINE 128	// maximum characters to receive and send at once
#define	MAXFRAME 256

extern int swap_connect(unsigned int addr, unsigned short port);
extern int swap_disconnect(int sd);
extern int sdp_send(int sd, char *buf, int length);
extern int sdp_receive(int sd, char *buf);
extern int sdp_receive_with_timer(int sd, char *buf, unsigned int expiration);

int session_id = 0;
int S = 0;	// frame number sent

int swap_open(unsigned int addr, unsigned short port)
{
	int	sockfd;		// sockect descriptor
	struct	sockaddr_in	servaddr;	// server address
	char	buf[MAXLINE];
	int	len, n;

	/*
	*	if the session is already open, then return error
	*/

	if (session_id != 0)
		return -1;

	/*
	*	connect to a server
	*/

	session_id = swap_connect(addr, port);	// in sdp.o

	/*
	*	return the seesion id
	*/

	return session_id;
}

int swap_write(int sd, char *buf, int length)
{
	int n;
	char frame[MAXFRAME]; // the frame is a string where the first 5 characters is the checksum, and the rest is the buf
	char ACK[] = "0";
	if (session_id == 0 || sd != session_id)
		return -1;

	/*
	*	send a DATA frame
	*/

	// ...
	char checksumString[6]; //checksum string used to hold the checksum string
	unsigned short calculation; // unsigned short used to hold the checksum value
	char Svalue[MAXFRAME]; //kinda unecessary, but it holds a string version of the frame number, this was used bc the program used to also send the frame number in the frame , but it was unecessary
	sprintf(Svalue, "%d", S);
	
	calculation	= checksum(buf, length);//cakcukate the checksum
	snprintf(checksumString, 6, "%u", calculation);// copy the checksum into the checksum string
	
	
	
	strcpy(frame, checksumString); //add the checksum string into the frame

	strcat(frame, buf);//add the buf into the frame
	
	printf("frame to be sent is: %s.\n", frame);
	printf("Frame number to be sent is: %s.\n", Svalue); 
	printf("checksum to be sent is: %s.\n", checksumString);
	printf("message to be sent is %s.\n", buf);
	

	
	n = sdp_send(sd, frame, length + 5); //send the frame with length +5 bceuase thats how long the checksum will be
	
	
	
	if(n != -1){
		printf("The DATA Frame: %d was sent to the server.\n", S); //frame was sent
		
	}else{
		printf("The DATA Frame: %d  was not sent to the server.\n", S);//frame failed to send
	}

	/*
	*	read a frame with a timer
	*/

	// ...
	int timer = sdp_receive_with_timer(sd, ACK, 6000); //timer of 6000 milisecons

	/*
	*	several different cases including disconnection
	*/

	// ...
	if(timer == -1){
		printf("There was a general error in the transmission.\n");
	}else if(timer == -2){
		printf("The session disconnected.\n"); //this usually happens around frame 14
	
	}else if(timer == -3){
		printf("The timer expired.\n");
		
		
	}else{
		
		if(ACK[0] == '1'){
		printf("Valid Acknowledgement recieved.. Message has been sent without errors..\n\n"); //printing the ACK
		S++;
		
		}else{
			printf("Invalid Acknowledgement recieved.. Message has been corrupted..\n\n");
		}
	}

	/*
	*	return the length sent
	*/

	// ...
	
	return n;
	
}

void swap_close(int sd)
{
	if (session_id == 0 || sd != session_id)
		return;

	else
		session_id = 0;

	swap_disconnect(sd);	// in sdp.o
}
