/*
*	swap_server.c
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>

#define	MAXLINE	128	// maximum characters to receive and send at once
#define MAXFRAME 256

extern int swap_accept(unsigned short port);
extern int swap_disconnect(int sd);
extern int sdp_send(int sd, char *buf, int length);
extern int sdp_receive(int sd, char *buf);
extern int sdp_receive_with_timer(int sd, char *buf, unsigned int expiration);

int session_id = 0;
int R = 0;	// frame number to receive

int swap_wait(unsigned short port)
{
	/*
	*	if the session is already open, then return error
	*/
	
	

	if (session_id != 0)
		return -1;

	/*
	*	accept a connection
	*/

	printf("Waiting for to recieve frame from client...\n");
	session_id = swap_accept(port);	// in sdp.o


	
	/*
	*	return a ssession id
	*/

	return session_id;
}

int swap_read(int sd, char *buf)
{
	int	n;
	char frame[MAXFRAME];// we will be recieving a frame, the first 5 bits will contain the checksum, the rest will be the datawords
	
	char dataWords[MAXLINE]; //this is where the recieved datawords will be placed after being seperated from the frame
	char recievedChecksum[6];// this is where the recieved checksum willbe stored
	char checksumString[6];//we create a local checksum that calculates using the datawords, the local checksum string will be placed here
	char ACK[] = "0";//acknowledgement
	

	if (session_id == 0 || sd != session_id)
		return -1;

	/*
	*	receive a frame without a timer
	*/
	// ...
	
	n = sdp_receive(sd, frame); //recieve the frame
	
	
	/*
	*	several cases
	*/

	// ...
	int m; // used for sending the acknowledgements

	if(n == -1){
		printf("There was a general error in the transmission.\n");
	}
	else if(n == -2){
		printf("The session disconnected.\n");
		
	}
	
	
	else{
		
		
		
		//char frameString[MAXFRAME];
		//strcpy(frameString,frame);
		
		int framelen = strlen(frame); //length of the recieved frame
		
		//for loop goes through the first five characters of the frame array, and places them into the recievedchecksum array 
		int i;
		for(i = 0; i < 5; i++){
			recievedChecksum[i] = frame[i];
		}

		




		//for loop goes through the rest of the frame and places the data ords into the dataWords array
		int j;
		for (j = 5; j < framelen; j++){
			dataWords[j-5] = frame[j];
		}
		
		

	
	
		
	
		unsigned short calculation; //unsigned short used for storing the checksum value
		calculation = checksum(dataWords, strlen(dataWords)); //creating the local checksum
		snprintf(checksumString, 6, "%u", calculation); //copying the local checksum into a string
		
		printf("Server has recieved message from client..\n");
		//printing values
		printf("frame recieved from client: %s.\n", frame);
		printf("frame number to recieve: %d.\n", R);
		//printf("length of the frame: %d.\n", framelen);
		
		printf("recieved checksum: %s.\n", recievedChecksum);
		printf("server checksum: %s.\n", checksumString);
		
		if(strcmp(recievedChecksum, checksumString) == 0){ //comparing the local checksum with the recieved checksum
			
			printf("checksums are matching.. sending Acknowledgement..\n"); //if the checksums match, send an ack 
			
			ACK[0] = '1';
			m = sdp_send(sd, ACK, 1); //send the ack
			if (m == -1){
				printf("Acknowledgement failed to send.\n"); 
			}else{
				
				printf("Acknowledgment successfully sent to client.\n");
				R++; //increase the expected frame number when the acknowledgement is succsessfully sent
				
			}
			
		}else{
			printf("checksums did not match.. sending negative acknowledgement..\n"); //send a negative ack
			ACK[0] = '0';
			
			m = sdp_send(sd, ACK, 1);
			if (m == -1){
				printf("Negative Acknowledgement failed to send.\n");
			}else{
				
				printf("Negative Acknowledgment successfully sent to client.\n");
				
				
			}
			
			
		}
		
		
	}
	
	
	

	/*
	*	copy the data field in the frame into buf, and return the length
	*/

	// ...
	strcpy(buf, dataWords);
	int len = strlen(buf);
	return n;

	
	
}

void swap_close(int sd)
{
	if (session_id == 0 || sd != session_id)
		return;

	else
		session_id = 0;

	swap_disconnect(sd);	// in sdp.o
}
