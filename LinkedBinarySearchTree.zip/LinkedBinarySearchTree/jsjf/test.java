package jsjf;

public class test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkedBinarySearchTree<Integer> tree = new LinkedBinarySearchTree<Integer>();
		
		tree.addElement(12);
		tree.addElement(8);
		tree.addElement(99);
		tree.addElement(6);
		tree.addElement(4);
		tree.addElement(1);
		tree.addElement(22);
		tree.addElement(45);
		
		System.out.println(tree);
		
		System.out.println("max : " + tree.findMax());
		System.out.println("min : " + tree.findMin());
		
		System.out.println("left tree : " + tree.getLeft());
		System.out.println("right tree: " + tree.getRight());
		
		tree.removeMax();
		tree.removeMin();
		
		System.out.println(tree);
		
		System.out.println("max : " + tree.findMax());
		System.out.println("min : " + tree.findMin());
		
		tree.removeMax();
		tree.removeMin();
		
		System.out.println(tree);
		
		System.out.println("max : " + tree.findMax());
		System.out.println("min : " + tree.findMin());
		

	
	

		
	}

}
